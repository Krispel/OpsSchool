#!/bin/bash
#add fix to exercise4-server2 here
adding server1 to /etc/hosts
