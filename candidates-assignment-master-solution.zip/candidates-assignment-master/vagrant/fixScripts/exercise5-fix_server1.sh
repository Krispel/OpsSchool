#!/bin/bash
#add fix to exercise5-server1 here
