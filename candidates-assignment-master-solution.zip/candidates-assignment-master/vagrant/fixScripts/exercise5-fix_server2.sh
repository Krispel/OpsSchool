#!/bin/bash
#add fix to exercise5-server2 here
