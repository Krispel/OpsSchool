#!/bin/bash
#add fix to exercise4-server1 here
adding server2 to /etc/hosts
