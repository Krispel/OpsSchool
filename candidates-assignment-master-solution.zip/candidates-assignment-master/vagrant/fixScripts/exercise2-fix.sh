#!/bin/bash
#add fix to exercise2 here
sudo nano /etc/hosts was with host name for  http://www.ascii-art.de
change it , reboot and we good to go:)
